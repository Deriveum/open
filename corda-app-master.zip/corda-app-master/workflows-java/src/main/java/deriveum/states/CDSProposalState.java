package deriveum.states;

import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import net.corda.core.contracts.BelongsToContract;
import net.corda.core.contracts.LinearState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.serialization.ConstructorForDeserialization;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@BelongsToContract(CDSContract.class)
public class CDSProposalState implements LinearState {
    private int amount;
    private int period;
    private Party insurer;
    private Party insured;
    private Party resolver;
    private Party verifier;
    private boolean isInsuredAgree;
    private boolean isResolverAgree;
    private boolean isVerifierAgree;
    private UniqueIdentifier linearId;

    @ConstructorForDeserialization
    public CDSProposalState(int amount, int period, Party insurer, Party insured, Party resolver, Party verifier,
                            boolean isInsuredAgree, boolean isResolverAgree, boolean isVerifierAgree, UniqueIdentifier linearId) {
        this.amount = amount;
        this.period = period;
        this.insurer = insurer;
        this.insured = insured;
        this.resolver = resolver;
        this.verifier = verifier;
        this.linearId = linearId;
        this.isInsuredAgree = isInsuredAgree;
        this.isResolverAgree = isResolverAgree;
        this.isVerifierAgree = isVerifierAgree;
    }

    public CDSProposalState(int amount, int period, Party insurer, Party insured, Party resolver, Party verifier,
                            boolean isInsuredAgree, boolean isResolverAgree, boolean isVerifierAgree) {
        this(amount, period, insurer, insured, resolver, verifier,  isInsuredAgree,  isResolverAgree,  isVerifierAgree, new UniqueIdentifier());
    }

    public int getAmount() {
        return amount;
    }

    public int getPeriod() {
        return period;
    }

    public Party getInsurer() {
        return insurer;
    }

    public Party getInsured() {
        return insured;
    }

    public Party getResolver() {
        return resolver;
    }

    public Party getVerifier() {
        return verifier;
    }

    public boolean isInsuredAgree() {
        return isInsuredAgree;
    }

    public boolean isResolverAgree() {
        return isResolverAgree;
    }

    public boolean isVerifierAgree() {
        return isVerifierAgree;
    }

    public CDSProposalState withInsuredAgree() {
        return new CDSProposalState(amount, period, insurer, insured, resolver, verifier,  true,  isResolverAgree,  isVerifierAgree);
    }

    public CDSProposalState withResolverAgree() {
        return new CDSProposalState(amount, period, insurer, insured, resolver, verifier,  isInsuredAgree,  true,  isVerifierAgree);
    }

    public CDSProposalState withVerifierAgree() {
        return new CDSProposalState(amount, period, insurer, insured, resolver, verifier,  isInsuredAgree,  isResolverAgree,  true);
    }

    @NotNull
    @Override
    public UniqueIdentifier getLinearId() {
        return this.linearId;
    }

    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {
        return ImmutableList.of(insurer, insured, verifier, resolver);
    }
}
