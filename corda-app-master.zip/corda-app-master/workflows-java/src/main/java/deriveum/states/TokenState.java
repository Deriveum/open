package deriveum.states;

import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import net.corda.core.contracts.BelongsToContract;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.LinearState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.serialization.ConstructorForDeserialization;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@BelongsToContract(CDSContract.class)
public class TokenState implements ContractState, LinearState {
    private final Party issuer;
    private Party owner;
    private int amount;
    private final UniqueIdentifier linearId;

    @ConstructorForDeserialization
    public TokenState(Party issuer, Party owner, int amount, UniqueIdentifier linearId) {
        this.issuer = issuer;
        this.owner = owner;
        this.amount = amount;
        this.linearId = linearId;
    }

    public Party getOwner() {
        return owner;
    }

    public Party getIssuer() {
        return issuer;
    }

    public int getAmount() {
        return amount;
    }

    public TokenState(Party issuer, Party owner, int amount) {
        this(issuer, owner, amount, new UniqueIdentifier());
    }

    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {
        return ImmutableList.of(issuer, owner);
    }

    @NotNull
    @Override
    public UniqueIdentifier getLinearId() {
        return this.linearId;
    }
}
