package deriveum.flows;

import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import deriveum.states.CDSProposalState;
import deriveum.states.TokenState;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.LedgerTransaction;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import org.jetbrains.annotations.NotNull;

import java.security.PublicKey;
import java.security.SignatureException;
import java.util.List;
import java.util.stream.Collectors;

public class ConvertTokenToCDSFlow {
    @InitiatingFlow
    @StartableByRPC
    public static class Initiator extends FlowLogic<UniqueIdentifier> {
        private Party insured;
        private Party resolver;
        private Party verifier;
        private UniqueIdentifier tokenId;
        int period;

        public Initiator(Party insured, Party resolver, Party verifier, int period, UniqueIdentifier tokenId) {
            this.insured = insured;
            this.resolver = resolver;
            this.verifier = verifier;
            this.tokenId = tokenId;
            this.period = period;
        }

        @Suspendable
        @Override
        public UniqueIdentifier call() throws FlowException {
            Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);
            QueryCriteria.LinearStateQueryCriteria inputCriteria = new QueryCriteria.LinearStateQueryCriteria(null, ImmutableList.of(tokenId), Vault.StateStatus.UNCONSUMED, null);
            StateAndRef inputStateAndRef = getServiceHub().getVaultService().queryBy(TokenState.class, inputCriteria).getStates().get(0);
            TokenState tokenState = (TokenState) inputStateAndRef.getState().getData();
            int amount = tokenState.getAmount();
            Party insurer = tokenState.getOwner();

            CDSProposalState cdsProposalState = new CDSProposalState(amount, period, insurer, insured, resolver, verifier, false, false, false);

            List<PublicKey> requiredSigners = cdsProposalState.getParticipants().stream()
                    .map(AbstractParty::getOwningKey)
                    .collect(Collectors.toList());
            requiredSigners.add(tokenState.getIssuer().getOwningKey());

            CDSContract.Commands.Modify tokenModify = new CDSContract.Commands.Modify();
            Command tokenCommand = new Command(tokenModify, requiredSigners);

            TransactionBuilder txBuilder = new TransactionBuilder(notary)
                    .addInputState(inputStateAndRef)
                    .addOutputState(cdsProposalState, CDSContract.ID)
                    .addCommand(tokenCommand);

            List<Party> otherParties = cdsProposalState.getParticipants()
                    .stream().map(el -> (Party) el)
                    .collect(Collectors.toList());
            otherParties.remove(getOurIdentity());
            otherParties.add(tokenState.getIssuer());

            List<FlowSession> sessions = otherParties
                    .stream().map(this::initiateFlow)
                    .collect(Collectors.toList());

            SignedTransaction partStx = getServiceHub().signInitialTransaction(txBuilder);
            SignedTransaction fullyStx = subFlow(new CollectSignaturesFlow(partStx, sessions));
            SignedTransaction finalisedTx = subFlow(new FinalityFlow(fullyStx, sessions));
            return finalisedTx.getTx().outputsOfType(CDSProposalState.class).get(0).getLinearId();
        }
    }

    @InitiatedBy(Initiator.class)
    public static class Responder extends FlowLogic<SignedTransaction> {
        private FlowSession counterpartySession;

        public Responder(FlowSession counterpartySession) {
            this.counterpartySession = counterpartySession;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {

            SignTransactionFlow signTransactionFlow = new SignTransactionFlow(counterpartySession) {

                @Override
                protected void checkTransaction(@NotNull SignedTransaction stx) throws FlowException {
                    try {
                        LedgerTransaction ledgerTx = stx.toLedgerTransaction(getServiceHub(), false);
                    } catch (SignatureException e) {
                        e.printStackTrace();
                    }
                }
            };
            SecureHash txId = subFlow(signTransactionFlow).getId();
            SignedTransaction finalisedTx = subFlow(new ReceiveFinalityFlow(counterpartySession, txId));
            return finalisedTx;
        }
    }

}
