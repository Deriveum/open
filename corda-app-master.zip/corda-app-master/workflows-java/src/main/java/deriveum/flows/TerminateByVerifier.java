package deriveum.flows;

import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import deriveum.states.CDSState;
import deriveum.states.TokenState;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;

import java.security.PublicKey;
import java.util.List;
import java.util.stream.Collectors;

import static net.corda.core.contracts.ContractsDSL.requireThat;

// -> Insured
public class TerminateByVerifier {
    @InitiatingFlow
    @StartableByRPC
    public static class Initiator extends FlowLogic<SignedTransaction> {
        private UniqueIdentifier contractId;
        private Party issuer;

        public Initiator(Party issuer, UniqueIdentifier contractId) {
            this.contractId = contractId;
            this.issuer = issuer;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {
            QueryCriteria.LinearStateQueryCriteria inputCriteria = new QueryCriteria.LinearStateQueryCriteria(null, ImmutableList.of(contractId), Vault.StateStatus.UNCONSUMED, null);
            StateAndRef inputStateAndRef = getServiceHub().getVaultService().queryBy(CDSState.class, inputCriteria).getStates().get(0);
            final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);

            CDSState cdsState = (CDSState) inputStateAndRef.getState().getData();

            TokenState tokenState = new TokenState(issuer, cdsState.getInsured(), cdsState.getAmount());

            List<PublicKey> requiredSigners = cdsState.getParticipants().stream()
                    .map(AbstractParty::getOwningKey)
                    .collect(Collectors.toList());
            requiredSigners.add(issuer.getOwningKey());

            Command command = new Command(new CDSContract.Commands.Terminate(), requiredSigners);

            TransactionBuilder txBuilder = new TransactionBuilder(notary)
                    .addInputState(inputStateAndRef)
                    .addOutputState(tokenState, CDSContract.ID)
                    .addCommand(command);

            List<Party> otherParties = cdsState.getParticipants()
                    .stream().map(el -> (Party) el)
                    .collect(Collectors.toList());
            otherParties.add(issuer);
            otherParties.remove(getOurIdentity());

            List<FlowSession> sessions = otherParties
                    .stream().map(this::initiateFlow)
                    .collect(Collectors.toList());

            SignedTransaction partStx = getServiceHub().signInitialTransaction(txBuilder);
            SignedTransaction fullyStx = subFlow(new CollectSignaturesFlow(partStx, sessions));
            return subFlow(new FinalityFlow(fullyStx, sessions));
        }

        @InitiatedBy(Initiator.class)
        public static class Responder extends FlowLogic<SignedTransaction> {
            private FlowSession counterpartySession;
            private SecureHash txWeJustSigned;

            public Responder(FlowSession counterpartySession) {
                this.counterpartySession = counterpartySession;
            }

            @Suspendable
            @Override
            public SignedTransaction call() throws FlowException {
                class SignTxFlow extends SignTransactionFlow {

                    private SignTxFlow(FlowSession flowSession, ProgressTracker progressTracker) {
                        super(flowSession, progressTracker);
                    }
                    @Override
                    protected void checkTransaction(SignedTransaction stx) {
                        txWeJustSigned = stx.getId();
                    }
                }
                counterpartySession.getCounterpartyFlowInfo().getFlowVersion();
                SignTxFlow signTxFlow = new SignTxFlow(counterpartySession, SignTransactionFlow.Companion.tracker());
                subFlow(signTxFlow);
                return subFlow(new ReceiveFinalityFlow(counterpartySession, txWeJustSigned));
            }
        }
    }
}