package deriveum.flows;

import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import deriveum.states.CDSProposalState;
import deriveum.states.CDSState;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import org.jetbrains.annotations.NotNull;

import java.security.PublicKey;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ExecuteCDSFlow {
    @InitiatingFlow
    @StartableByRPC
    public static class Initiator extends FlowLogic<SignedTransaction> {

        private UniqueIdentifier proposalId;

        public Initiator(UniqueIdentifier proposalId) {
            this.proposalId = proposalId;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {
            QueryCriteria.LinearStateQueryCriteria inputCriteria = new QueryCriteria.LinearStateQueryCriteria(null, ImmutableList.of(proposalId), Vault.StateStatus.UNCONSUMED, null);
            StateAndRef inputStateAndRef = getServiceHub().getVaultService().queryBy(CDSProposalState.class, inputCriteria).getStates().get(0);
            Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);

            CDSProposalState cdsProposalState = (CDSProposalState) inputStateAndRef.getState().getData();
            CDSState cdsState = new CDSState(cdsProposalState.getAmount(), cdsProposalState.getPeriod(), 1, new Date().getTime(),
                    cdsProposalState.getInsurer(), cdsProposalState.getInsured(), cdsProposalState.getResolver(),
                    cdsProposalState.getVerifier(), cdsProposalState.getLinearId());

            List<PublicKey> requiredSigners = cdsState.getParticipants().stream()
                    .map(AbstractParty::getOwningKey)
                    .collect(Collectors.toList());

            Command command = new Command(new CDSContract.Commands.Execute(), requiredSigners);

            TransactionBuilder txBuilder = new TransactionBuilder(notary)
                    .addInputState(inputStateAndRef)
                    .addOutputState(cdsState, CDSContract.ID)
                    .addCommand(command);

            List<Party> otherParties = cdsState.getParticipants()
                    .stream().map(el -> (Party) el)
                    .collect(Collectors.toList());
            otherParties.remove(getOurIdentity());

            List<FlowSession> sessions = otherParties
                    .stream().map(this::initiateFlow)
                    .collect(Collectors.toList());

            SignedTransaction partStx = getServiceHub().signInitialTransaction(txBuilder);
            SignedTransaction fullyStx = subFlow(new CollectSignaturesFlow(partStx, sessions));
            return subFlow(new FinalityFlow(fullyStx, sessions));
        }

        @InitiatedBy(Initiator.class)
        public static class Responder extends FlowLogic<SignedTransaction> {
            private FlowSession counterpartySession;

            public Responder(FlowSession counterpartySession) {
                this.counterpartySession = counterpartySession;
            }

            @Suspendable
            @Override
            public SignedTransaction call() throws FlowException {
                SignTransactionFlow signTransactionFlow = new SignTransactionFlow(counterpartySession) {

                    @Override
                    protected void checkTransaction(@NotNull SignedTransaction stx) throws FlowException {


                    }
                };
                SecureHash txId = subFlow(signTransactionFlow).getId();
                SignedTransaction finalisedTx = subFlow(new ReceiveFinalityFlow(counterpartySession, txId));
                return finalisedTx;
            }
        }
    }
}