package deriveum.flows;

import co.paralleluniverse.fibers.Suspendable;
import deriveum.contracts.CDSContract;
import deriveum.states.TokenState;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.ContractState;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;


import java.security.PublicKey;
import java.util.List;
import java.util.stream.Collectors;

import static net.corda.core.contracts.ContractsDSL.requireThat;


public class IssueTokenFlow {
    @InitiatingFlow
    @StartableByRPC
    public static class Initiator extends FlowLogic<SignedTransaction> {
        private Boolean isIssuer;
        private Party owner;
        private int amount;

        public Initiator(Boolean isIssuer, Party owner, int amount) {
            this.isIssuer = isIssuer;
            this.owner = owner;
            this.amount = amount;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {
            final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);
            final Party insurer;
            final Party bank;

            if (isIssuer) {
                bank = getOurIdentity();
                insurer = owner;
            } else {
                bank = owner;
                insurer = getOurIdentity();
            }


            TokenState tokenState = new TokenState(bank, insurer, amount);
            List<PublicKey> participantsKeys = tokenState.getParticipants().stream()
                    .map(AbstractParty::getOwningKey)
                    .collect(Collectors.toList());

            final Command<CDSContract.Commands.Issue> issueCommand =
                    new Command<>(new CDSContract.Commands.Issue(), participantsKeys);


            final TransactionBuilder builder = new TransactionBuilder(notary);
            builder.addOutputState(tokenState, CDSContract.ID);
            builder.addCommand(issueCommand);
            builder.verify(getServiceHub());


            List<Party> otherParties = tokenState.getParticipants()
                    .stream().map(el -> (Party) el)
                    .collect(Collectors.toList());

            otherParties.remove(getOurIdentity());

            List<FlowSession> sessions = otherParties
                    .stream().map(this::initiateFlow)
                    .collect(Collectors.toList());

            final SignedTransaction ptx = getServiceHub().signInitialTransaction(builder);
            SignedTransaction stx = subFlow(new CollectSignaturesFlow(ptx, sessions));
            return subFlow(new FinalityFlow(stx, sessions));
        }
    }

    @InitiatedBy(Initiator.class)
    public static class Responder extends FlowLogic<SignedTransaction> {
        private final FlowSession counterpartySession;
        private SecureHash txWeJustSigned;

        public Responder(FlowSession counterpartySession) {
            this.counterpartySession = counterpartySession;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {

            class SignTxFlow extends SignTransactionFlow {

                private SignTxFlow(FlowSession flowSession, ProgressTracker progressTracker) {
                    super(flowSession, progressTracker);
                }

                @Override
                protected void checkTransaction(SignedTransaction stx) {
                    requireThat(req -> {
                        ContractState output = stx.getTx().getOutputs().get(0).getData();
                        req.using("This must be an Token transaction", output instanceof TokenState);
                        return null;
                    });
                    txWeJustSigned = stx.getId();
                }
            }
            counterpartySession.getCounterpartyFlowInfo().getFlowVersion();
            SignTxFlow signTxFlow = new SignTxFlow(counterpartySession, SignTransactionFlow.Companion.tracker());
            subFlow(signTxFlow);
            return subFlow(new ReceiveFinalityFlow(counterpartySession, txWeJustSigned));
        }

    }
}
