package deriveum.flows;

import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import deriveum.contracts.CDSContract;
import deriveum.states.CDSState;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import org.jetbrains.annotations.NotNull;

import java.security.PublicKey;
import java.util.List;
import java.util.stream.Collectors;


public class InitiateContractTermination {
    @InitiatingFlow
    @StartableByRPC
    public static class Initiator extends FlowLogic<SignedTransaction> {
        private UniqueIdentifier contractId;

        public Initiator(UniqueIdentifier contractId) {
            this.contractId = contractId;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {
            QueryCriteria.LinearStateQueryCriteria inputCriteria = new QueryCriteria.LinearStateQueryCriteria(null, ImmutableList.of(contractId), Vault.StateStatus.UNCONSUMED, null);
            StateAndRef inputStateAndRef = getServiceHub().getVaultService().queryBy(CDSState.class, inputCriteria).getStates().get(0);
            final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);

            CDSState cdsState = (CDSState) inputStateAndRef.getState().getData();

            Party ourIdentity = getOurIdentity();
            boolean isInsured = cdsState.getInsured().equals(ourIdentity);
            boolean isInsurer = cdsState.getInsurer().equals(ourIdentity);

            CDSState cdsStateModified;
            if (cdsState.getState() == 1) {
                if (isInsured) {
                    cdsStateModified = cdsState.withInsuredAgreeOnTermination();
                } else if (isInsurer) {
                    cdsStateModified = cdsState.withInsurerAgreeOnTermination();
                } else {
                    throw new IllegalStateException("Only Insured or Insurer can agree on contract termination");
                }
            } else if (cdsState.getState() == 2 && isInsurer) {
                cdsStateModified = cdsState.withBothAgreeOnTermination();
            } else if (cdsState.getState() == 3 && isInsured) {
                cdsStateModified = cdsState.withBothAgreeOnTermination();
            } else {
                throw new IllegalStateException("Undefined state");
            }

            List<PublicKey> requiredSigners = cdsStateModified.getParticipants().stream()
                    .map(AbstractParty::getOwningKey)
                    .collect(Collectors.toList());

            Command command = new Command(new CDSContract.Commands.InitiateTermination(), requiredSigners);

            TransactionBuilder txBuilder = new TransactionBuilder(notary)
                    .addInputState(inputStateAndRef)
                    .addOutputState(cdsStateModified, CDSContract.ID)
                    .addCommand(command);


            List<Party> otherParties = cdsStateModified.getParticipants()
                    .stream().map(el -> (Party) el)
                    .collect(Collectors.toList());
            otherParties.remove(getOurIdentity());

            List<FlowSession> sessions = otherParties
                    .stream().map(this::initiateFlow)
                    .collect(Collectors.toList());

            SignedTransaction partStx = getServiceHub().signInitialTransaction(txBuilder);
            SignedTransaction fullyStx = subFlow(new CollectSignaturesFlow(partStx, sessions));
            return subFlow(new FinalityFlow(fullyStx, sessions));

        }
    }

    @InitiatedBy(Initiator.class)
    public static class Responder extends FlowLogic<SignedTransaction> {
        private FlowSession counterpartySession;

        public Responder(FlowSession counterpartySession) {
            this.counterpartySession = counterpartySession;
        }

        @Suspendable
        @Override
        public SignedTransaction call() throws FlowException {

            SignTransactionFlow signTransactionFlow = new SignTransactionFlow(counterpartySession) {

                @Override
                protected void checkTransaction(@NotNull SignedTransaction stx) throws FlowException {

                }
            };
            SecureHash txId = subFlow(signTransactionFlow).getId();

            SignedTransaction finalisedTx = subFlow(new ReceiveFinalityFlow(counterpartySession, txId));
            return finalisedTx;
        }
    }
}