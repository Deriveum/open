package deriveum.contracts;

import deriveum.states.CDSProposalState;
import deriveum.states.CDSState;
import deriveum.states.TokenState;
import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.CommandWithParties;
import net.corda.core.contracts.Contract;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.transactions.LedgerTransaction;
import org.jetbrains.annotations.NotNull;

import java.security.PublicKey;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import static net.corda.core.contracts.ContractsDSL.requireSingleCommand;

public class CDSContract implements Contract {
    public static String ID = "deriveum.contracts.CDSContract";

    @Override
    public void verify(@NotNull LedgerTransaction tx) throws IllegalArgumentException {
        final CommandWithParties<Commands> command = requireSingleCommand(tx.getCommands(), Commands.class);
        final Commands commandData = command.getValue();

        if (commandData instanceof Commands.Issue) {
            if (tx.getInputStates().size() > 0) {
                throw new IllegalArgumentException("No inputs should be consumed when issuing a Token.");
            }
            if (tx.getOutputStates().size() != 1) {
                throw new IllegalArgumentException("Only one output state should be created when issuing a Token.");
            }
            TokenState outputState = tx.outputsOfType(TokenState.class).get(0);
            if (outputState.getAmount() < 0) {
                throw new IllegalArgumentException("A newly issued Token must have a positive amount.");
            }
            if (outputState.getOwner().getOwningKey().equals(outputState.getIssuer().getOwningKey())) {
                throw new IllegalArgumentException("The issuer and owner cannot have the same identity.");
            }
            List<PublicKey> signers = tx.getCommands().get(0).getSigners();
            HashSet<PublicKey> signersSet = new HashSet<>();
            for (PublicKey key : signers) {
                signersSet.add(key);
            }

            List<AbstractParty> participants = tx.getOutputStates().get(0).getParticipants();
            HashSet<PublicKey> participantKeys = new HashSet<>();
            for (AbstractParty party : participants) {
                participantKeys.add(party.getOwningKey());
            }
            if (!signersSet.containsAll(participantKeys) && signersSet.size() != 2) {
                throw new IllegalArgumentException("The issuer and owner together only may sign Token issue transaction.");
            }
//            CordaX500Name theIssuer = new CordaX500Name("PartyA", "London", "GB");
//            CordaX500Name tokenIssuer = outputState.getIssuer().getName();
//            if (!tokenIssuer.equals(theIssuer)) {
//                throw new IllegalArgumentException("Only " + theIssuer + " can be issuer");
//            }
        }

        if (commandData instanceof Commands.Execute) {
            CDSProposalState input = tx.inputsOfType(CDSProposalState.class).get(0);
            if (!input.isInsuredAgree()){
                throw new IllegalStateException("Insured must agree");
            }
            if (!input.isResolverAgree()){
                throw new IllegalStateException("Resolver must agree");
            }
            if (!input.isVerifierAgree()){
                throw new IllegalStateException("Verifier must agree");
            }
        }

        if (commandData instanceof Commands.TerminateDueToExpiration) {
            CDSState input = tx.inputsOfType(CDSState.class).get(0);
            long period = input.getPeriod() * 24 * 60 * 60 * 1000;
            long createdAtTimestamp = input.getCreatedAtTimestamp();
            long now = new Date().getTime();

            if (createdAtTimestamp + period > now) {
                throw new IllegalStateException("The contract has not expired");
            }
        }
        if (commandData instanceof Commands.TerminateByPartiesAgreement) {
            CDSState input = tx.inputsOfType(CDSState.class).get(0);
            int state = input.getState();
            if (state != 4){
                throw new IllegalStateException("Both parties must agree on contract termination");
            }
        }
    }

    public interface Commands extends CommandData {
        class Issue implements Commands {}
        class Modify implements Commands {}
        class InitiateTermination implements Commands{};
        class Execute implements Commands {};
        class Propose implements Commands {};
        class Accept implements Commands{};
        class Terminate implements Commands{};
        class TerminateDueToExpiration implements Commands{};
        class TerminateByPartiesAgreement implements Commands{};
    }
}
